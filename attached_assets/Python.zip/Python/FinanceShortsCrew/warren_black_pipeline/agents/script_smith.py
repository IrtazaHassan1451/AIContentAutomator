"""
ScriptSmith Agent

Generates engaging, punchy YouTube short-form scripts in the style of
Warren Black - a classy, bold financial strategist.
"""

import random
import time
from datetime import datetime

class ScriptSmith:
    def __init__(self):
        """Initialize the ScriptSmith agent."""
        self.persona = "Warren Black"
        self.tone = ["classy", "bold", "witty", "smart", "provocative", "insightful"]
        self.max_word_count = 200  # Short-form script word limit
    
    def generate_script(self, topic):
        """
        Generate a punchy short-form YouTube script in Warren Black style.
        
        Args:
            topic (dict or str): Topic to create script about (can be dict with 'title' or string)
            
        Returns:
            str: Well-formatted script ready for voiceover
        """
        # Extract topic title if a dictionary was passed
        if isinstance(topic, dict) and 'title' in topic:
            topic_title = topic['title']
        else:
            topic_title = str(topic)
        
        # In production, this would call a language model API like GPT
        # For now we'll use mock scripts based on the topic
        
        # Simulate some processing time
        time.sleep(1)
        
        # Get an appropriate script based on the topic
        script = self._get_mock_script(topic_title)
        
        # Print the result for console-based interface
        print(f"\n--- SCRIPTSMITH RESULTS ---")
        print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Topic: {topic_title}")
        print(f"Word count: {len(script.split())}")
        print(f"\nScript:\n{script}")
        
        return script
    
    def _get_mock_script(self, topic_title):
        """
        Generate a mock script based on the topic.
        This would be replaced with actual LLM API calls in production.
        
        Args:
            topic_title (str): The title of the topic
            
        Returns:
            str: A mock script relevant to the topic
        """
        # Map of topic keywords to script templates
        scripts = {
            "wealth": """
[INTENSE] Do you know why the 1% own 99% of the wealth?

[SERIOUS] It's not luck. It's not inheritance. It's leverage.

[DRAMATIC PAUSE] The wealthy understand something that 99% of people don't...

Money isn't wealth. Control is wealth.

[LEANING IN] When you own assets that generate cash flow, you control economic resources.

[BOLD] But here's what they don't teach you in school:

The rich don't save money - they deploy capital.
They don't fear debt - they use OPM: Other People's Money.
They don't work for income - they build equity.

[POWERFUL ENDING] Stop playing the game by the wrong rules.

I'm Warren Black, and if you want to build real wealth, stop saving... start owning.

[TAG] Follow for more financial truth bombs they don't want you to know.
""",
            
            "debt": """
[CONFIDENT] Let me tell you how the ultra-wealthy use debt as a weapon.

[INTRIGUING] When you take a loan, you're a victim. When they take a loan, they're strategists.

[LEANING IN] Here's the playbook:

Step 1: Buy appreciating assets - real estate, businesses, securities.
Step 2: Instead of selling these assets, borrow against them at low interest.
Step 3: Use the borrowed money to buy MORE appreciating assets.
Step 4: Repeat until you own half the world.

[DRAMATIC] They never sell, so they never pay capital gains tax.
Their assets appreciate faster than their interest payments.

[POWERFUL] This is how billionaires pay less tax than their secretaries.

I'm Warren Black, and understanding debt is the first step to financial freedom.

[TAG] Follow for more wealth strategies they don't teach in school.
""",
            
            "AI": """
[INTENSE] AI isn't just changing technology. It's reshaping the entire stock market beneath your feet.

[SERIOUS] The S&P 500 now has 7 companies representing over 30% of its value.

[LEANING IN] This concentration hasn't happened since the 1970s.

What's driving it? Artificial intelligence arms race.

[BOLD] The market isn't betting on today's AI profits. It's betting on who will own the future.

Microsoft, Google, NVIDIA - they're not tech companies anymore.
They're infrastructure for a new economic reality.

[WARNING] This creates massive opportunity AND risk.

I'm Warren Black, and the greatest wealth transfer of our lifetime is happening right now.

[TAG] Follow for more insights on navigating the AI economy.
""",
            
            "crypto": """
[DRAMATIC] The crypto market is showing the same indicators we saw before the last three crashes.

[INTENSE] Excessive leverage. Declining volumes. Diverging indices.

[LEANING IN] The smart money is already positioning.

When institutions start quietly exiting while telling retail to "HODL" - that's your warning sign.

[BOLD] But crashes create millionaires just as reliably as they destroy portfolio values.

Position sizing. Counter-cyclical assets. Cash reserves.

These aren't just buzzwords. They're your financial survival kit.

[POWERFUL] Winter is coming to crypto. The prepared will thrive.

I'm Warren Black, and remember - fortunes aren't made in bull markets. They're made preparing for the next one.

[TAG] Follow for financial strategies that work in any market condition.
""",
            
            "Buffett": """
[AUTHORITATIVE] Warren Buffett has outperformed the market for 60+ years. Here's what he knows that you don't.

[LEANING IN] It's not picking stocks. It's emotional discipline.

When everyone is greedy - be fearful.
When everyone is fearful - be greedy.

[DRAMATIC] But the real secret? Buffett doesn't invest in businesses. He invests in moats.

Economic moats - sustainable competitive advantages that protect profits from competitors.

[BOLD] Brands. Network effects. Switching costs. Cost advantages.

These are the four moats that have built his $100B fortune.

[POWERFUL] I'm Warren Black, and the key to investing isn't finding the next big thing - it's finding what will still be profitable in 20 years.

[TAG] Follow for more timeless wealth principles.
""",

            "portfolio": """
[INTENSE] The 60/40 portfolio is dead. And it's not coming back.

[SERIOUS] For decades, the formula was simple: 60% stocks, 40% bonds.
When stocks fell, bonds rose. Balance restored.

[LEANING IN] But in 2022, something broke. Stocks AND bonds crashed simultaneously.

The negative correlation that protected investors for generations... vanished.

[BOLD] Why? Because we've entered an era of persistent inflation and real asset scarcity.

The new portfolio needs:
- 30% stocks
- 30% real assets
- 20% alternative income
- 20% uncorrelated strategies

[POWERFUL] I'm Warren Black, and if your financial advisor is still pushing 60/40, they're driving with a map from an economic world that no longer exists.

[TAG] Follow for portfolio strategies built for the 2020s, not the 1980s.
""",

            "inflation": """
[DRAMATIC] Inflation isn't just a number on the news. It's a hidden tax stealing your financial future.

[INTENSE] At 5% inflation, your money loses HALF its value in just 14 years.

[LEANING IN] Your $100,000 savings becomes worth $50,000 in purchasing power.
And that's AFTER you pay income tax on any interest earned.

[BOLD] The wealthy don't fight inflation - they ride it.

Real estate. Commodities. Businesses with pricing power.
These assets don't just keep pace with inflation, they BENEFIT from it.

[POWERFUL] I'm Warren Black, and cash might feel safe, but it's guaranteed to depreciate.

[TAG] Follow for strategies to not just preserve, but grow your wealth in an inflationary world.
""",

            "index": """
[PROVOCATIVE] Index funds have created the biggest investment bubble in financial history.

[SERIOUS] When everyone buys the same stocks regardless of price, that's the definition of a bubble.

[LEANING IN] Passive investing now controls over 50% of all stock assets.

What happens when fund flows reverse? When retiring boomers need to sell?

[BOLD] The stocks with the largest market caps get the most money from indexes.
Not because they're better companies. Just because they're bigger.

This creates a dangerous feedback loop driving valuations to unsustainable levels.

[POWERFUL] I'm Warren Black, and index investing works until it doesn't. Diversification isn't just owning everything - it's owning different things.

[TAG] Follow for strategies to protect yourself from the coming passive investing unwind.
"""
        }
        
        # Find the most relevant script based on keywords in the topic
        for keyword, script in scripts.items():
            if keyword.lower() in topic_title.lower():
                return script.strip()
        
        # Default script if no keyword matches
        return """
[INTENSE] Financial education is the greatest edge in today's economy.

[SERIOUS] The gap between the financially literate and financially confused is becoming the new wealth divide.

[LEANING IN] Schools teach you how to be an employee. But they don't teach you how money actually works.

The tax code. Banking system. Securities markets. Monetary policy.
These aren't just topics for experts - they're the operating system of our world.

[BOLD] And here's the truth: If you don't understand the system, the system will use you.

Your labor. Your savings. Your attention. All siphoned to those who do understand.

[POWERFUL] I'm Warren Black, and the greatest investment you can make is in your financial intelligence.

[TAG] Follow for the financial education you should have received decades ago.
""".strip()

    def format_for_teleprompter(self, script):
        """
        Format a script for easier reading on a teleprompter.
        
        Args:
            script (str): Raw script text
            
        Returns:
            str: Formatted script with larger font, spacing, etc.
        """
        # This would be implemented for actual production
        # Here we'll just return the script with some basic formatting
        formatted = "----- WARREN BLACK TELEPROMPTER -----\n\n"
        formatted += script
        formatted += "\n\n----- END OF SCRIPT -----"
        return formatted


if __name__ == "__main__":
    # Test the ScriptSmith agent when run directly
    smith = ScriptSmith()
    test_topic = {"title": "How the rich use debt to get richer", 
                 "source": "Reddit r/finance",
                 "hook": "Discover the secret financial strategy the wealthy use to build empires."}
    script = smith.generate_script(test_topic)
    print("\nTELEPROMPTER FORMAT:")
    print(smith.format_for_teleprompter(script))
