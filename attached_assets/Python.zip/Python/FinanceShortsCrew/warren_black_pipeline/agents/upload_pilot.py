"""
UploadPilot Agent

Prepares metadata for YouTube video uploads including titles,
descriptions, tags, and other upload settings.
"""

import json
import time
import random
from datetime import datetime

class UploadPilot:
    def __init__(self):
        """Initialize the UploadPilot agent."""
        self.platform = "YouTube"
        self.channel = "Warren Black Finance"
        self.hashtag_pool = [
            "finance", "money", "investing", "wealth", "stocks", 
            "crypto", "warrenblack", "financetips", "moneytips",
            "financialadvice", "personalfinance", "moneymanagement",
            "stockmarket", "passiveincome", "financialliteracy",
            "financialfreedom", "moneymindset", "wealthbuilding",
            "moneymastery", "richvspoor", "millionairemindset",
            "debtstrategies", "investingforbeginners", "shorts"
        ]
    
    def generate_metadata(self, topic, script=None, output_path=None):
        """
        Generate metadata for video upload based on the topic and script.
        
        Args:
            topic (dict or str): Topic information (can be dict with 'title' or string)
            script (str, optional): Script content for crafting description
            output_path (str, optional): Path to save metadata. Defaults to "upload_data.json".
            
        Returns:
            dict: Metadata for the video upload
        """
        # Extract topic title if a dictionary was passed
        if isinstance(topic, dict) and 'title' in topic:
            topic_title = topic['title']
        else:
            topic_title = str(topic)
        
        # Use default output path if not specified
        output_path = output_path or "upload_data.json"
        
        # Generate the metadata
        title = self._generate_title(topic_title)
        description = self._generate_description(topic_title, script)
        hashtags = self._generate_hashtags(topic_title)
        
        # Create the metadata dictionary
        metadata = {
            "title": title,
            "description": description,
            "tags": hashtags,
            "category": "Education",
            "visibility": "Public",
            "made_for_kids": False,
            "thumbnail_file": "thumbnail.png",
            "video_file": "output_video.mp4",
            "language": "en-US",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        # Save the metadata to a file
        try:
            with open(output_path, "w") as f:
                json.dump(metadata, f, indent=4)
        except Exception as e:
            print(f"Error saving metadata: {e}")
        
        # Print the result for console-based interface
        print(f"\n--- UPLOADPILOT RESULTS ---")
        print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Title: \"{title}\"")
        print(f"Tags: {', '.join(hashtags[:5])}...")
        print(f"Description length: {len(description)} characters")
        print(f"✅ Upload metadata saved to '{output_path}'")
        
        return metadata
    
    def _generate_title(self, topic_title):
        """
        Generate an engaging title for YouTube based on the topic.
        
        Args:
            topic_title (str): The original topic title
            
        Returns:
            str: Engaging YouTube title
        """
        # Make the title more engaging and add emojis
        topic_keywords = topic_title.lower()
        
        # Map of emojis for different financial topics
        emoji_map = {
            "wealth": "💰",
            "rich": "💸",
            "money": "💲",
            "invest": "📈",
            "stock": "📊",
            "crypto": "₿",
            "bitcoin": "₿",
            "debt": "🏦",
            "millionaire": "🤑",
            "billionaire": "🤑",
            "inflation": "📉",
            "saving": "🏆",
            "buffett": "🧠",
            "ai": "🤖",
            "artificial intelligence": "🤖",
            "portfolio": "📒"
        }
        
        # Find appropriate emojis based on keywords
        selected_emojis = []
        for keyword, emoji in emoji_map.items():
            if keyword in topic_keywords and emoji not in selected_emojis:
                selected_emojis.append(emoji)
        
        # Limit to max 2 emojis
        selected_emojis = selected_emojis[:2]
        
        # Create an attention-grabbing title
        if "how" in topic_title.lower() or "why" in topic_title.lower():
            # If it's already a "how" or "why" question, just enhance it
            title = topic_title
        else:
            # Otherwise, transform it into a more engaging format
            if random.choice([True, False]):
                title = f"How {topic_title}"
            else:
                title = f"Why {topic_title}"
        
        # Add emojis if we found any
        if selected_emojis:
            title = f"{title} {' '.join(selected_emojis)}"
        
        # Ensure title isn't too long (YouTube limit is 100 characters)
        if len(title) > 90:
            title = title[:87] + "..."
        
        return title
    
    def _generate_description(self, topic_title, script=None):
        """
        Generate a description for the YouTube video.
        
        Args:
            topic_title (str): The topic title
            script (str, optional): The script content
            
        Returns:
            str: YouTube video description
        """
        # Start with a hook from the topic
        description = f"{topic_title}\n\n"
        
        # Add a brief explanation
        description += "In this video, Warren Black breaks down what you need to know about "
        description += f"{topic_title.lower()}, and why it matters for your financial future.\n\n"
        
        # Add a snippet from the script if available
        if script:
            # Extract a compelling snippet (first few lines, skipping direction tags)
            lines = [line.strip() for line in script.split('\n') if line.strip()]
            content_lines = [line for line in lines if not (line.startswith('[') and ']' in line)]
            
            if content_lines:
                snippet = " ".join(content_lines[:3])
                description += f"\"{snippet}...\"\n\n"
        
        # Add standard channel information
        description += "🔔 Subscribe for more financial insights that schools don't teach: "
        description += "https://youtube.com/@WarrenBlackFinance\n\n"
        
        description += "🔗 Connect with Warren Black:\n"
        description += "Instagram: @warrenblackfinance\n"
        description += "Twitter: @warrenblackfin\n"
        description += "TikTok: @warrenblackfinance\n\n"
        
        description += "📚 Warren Black is a financial strategist teaching the next million minds "
        description += "how money really works. From stock market secrets to wealth building strategies, "
        description += "Warren breaks down complex financial concepts into actionable steps.\n\n"
        
        description += "#WarrenBlack #FinancialEducation #MoneyMindset"
        
        return description
    
    def _generate_hashtags(self, topic_title):
        """
        Generate relevant hashtags for the video based on topic.
        
        Args:
            topic_title (str): The topic title
            
        Returns:
            list: List of hashtag strings
        """
        # Start with some standard tags
        tags = ["WarrenBlack", "FinancialEducation", "MoneyMindset", "Shorts"]
        
        # Add topic-specific tags based on keywords
        topic_keywords = topic_title.lower()
        
        # Map of topic keywords to relevant tags
        tag_map = {
            "wealth": ["WealthBuilding", "WealthStrategy", "MillionaireMindset"],
            "rich": ["RichVsPoor", "MillionaireMindset", "WealthGap"],
            "money": ["MoneyTips", "PersonalFinance", "MoneyManagement"],
            "invest": ["InvestingTips", "StockMarket", "InvestingForBeginners"],
            "stock": ["StockMarket", "Stocks", "WallStreet"],
            "crypto": ["Cryptocurrency", "Bitcoin", "CryptoInvesting"],
            "bitcoin": ["Bitcoin", "Cryptocurrency", "CryptoInvesting"],
            "debt": ["DebtStrategy", "GoodDebt", "LeveragingDebt"],
            "millionaire": ["MillionaireMindset", "WealthBuilding", "FinancialFreedom"],
            "inflation": ["InflationProtection", "EconomicTrends", "BeatInflation"],
            "saving": ["SavingMoney", "FinancialGoals", "BudgetTips"],
            "buffett": ["WarrenBuffett", "ValueInvesting", "InvestingLegends"],
            "ai": ["ArtificialIntelligence", "TechStocks", "FutureOfFinance"],
            "portfolio": ["InvestmentPortfolio", "AssetAllocation", "DiversifyInvestments"]
        }
        
        # Add relevant tags based on keywords in the topic
        for keyword, related_tags in tag_map.items():
            if keyword in topic_keywords:
                # Add up to 2 tags from each matched keyword
                for tag in related_tags[:2]:
                    if tag not in tags:
                        tags.append(tag)
        
        # Add a few general finance tags from the pool
        remaining_slots = 15 - len(tags)  # YouTube allows up to 15 tags
        if remaining_slots > 0:
            # Filter out tags that are already selected
            available_tags = [tag for tag in self.hashtag_pool if tag not in tags]
            # Add random selection from remaining pool
            tags.extend(random.sample(available_tags, min(remaining_slots, len(available_tags))))
        
        return tags
    
    def mock_youtube_api_check(self, title, description, tags):
        """
        Mock function to simulate YouTube API compatibility check.
        Would be replaced with actual API call in production.
        
        Args:
            title (str): Video title
            description (str): Video description
            tags (list): Video tags
            
        Returns:
            dict: Mock response from YouTube API
        """
        # Simulate API delay
        time.sleep(0.5)
        
        # Check for potential issues
        issues = []
        if len(title) > 100:
            issues.append("Title exceeds YouTube's 100 character limit")
        if len(description) > 5000:
            issues.append("Description exceeds YouTube's 5000 character limit")
        if len(tags) > 15:
            issues.append("Exceeded YouTube's 15 tag limit")
        
        # Mock response structure
        return {
            "success": len(issues) == 0,
            "issues": issues,
            "title_length": len(title),
            "description_length": len(description),
            "tag_count": len(tags),
            "request_id": f"req_{random.randint(10000, 99999)}"
        }


if __name__ == "__main__":
    # Test the UploadPilot agent when run directly
    pilot = UploadPilot()
    
    test_topics = [
        "How the rich use debt to get richer",
        "Why 1% of people own 99% of the wealth",
        "AI's impact on global stock markets"
    ]
    
    for topic in test_topics:
        metadata = pilot.generate_metadata(topic)
        print(f"\nTitle: {metadata['title']}")
        print(f"Tags: {metadata['tags']}")
        print("-" * 50)
