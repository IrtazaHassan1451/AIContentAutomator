# Warren Black Finance Shorts - Automated Content Pipeline

This project implements a modular multi-agent system for generating YouTube finance shorts content automatically. The system consists of six specialized agents, each handling a different part of the content creation process, from finding trending topics to preparing upload metadata.

## Project Structure

