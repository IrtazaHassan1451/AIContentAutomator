"""
Warren Black Finance Shorts - Automated Content Pipeline

Main pipeline integrating all the agents to automate the creation
of finance-focused YouTube Shorts content.
"""

import os
import sys
import json
import time
import argparse
from datetime import datetime

# Add the parent directory to the path so we can import the agents
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the agent modules
from warren_black_pipeline.agents.trend_seeker import TrendSeeker
from warren_black_pipeline.agents.script_smith import ScriptSmith
from warren_black_pipeline.agents.vox_crafter import VoxCrafter
from warren_black_pipeline.agents.clip_maker import ClipMaker
from warren_black_pipeline.agents.thumb_wizard import ThumbWizard
from warren_black_pipeline.agents.upload_pilot import UploadPilot

def run_agent(agent_name, input_data=None):
    """
    Run a specific agent with the given input data.

    Args:
        agent_name (str): Name of the agent to run
        input_data: Data to pass to the agent (varies by agent)

    Returns:
        The output of the agent's main function
    """
    print(f"\n{'=' * 60}")
    print(f"RUNNING AGENT: {agent_name.upper()}")
    print(f"{'=' * 60}")

    if agent_name == "trend_seeker":
        agent = TrendSeeker()
        return agent.get_trending_topics()

    elif agent_name == "script_smith":
        if not input_data:
            print("Error: script_smith requires a topic input")
            return None
        agent = ScriptSmith()
        return agent.generate_script(input_data)

    elif agent_name == "vox_crafter":
        if not input_data:
            print("Error: vox_crafter requires a script input")
            return None
        agent = VoxCrafter()
        return agent.generate_voiceover(input_data)

    elif agent_name == "clip_maker":
        if not input_data:
            print("Error: clip_maker requires a script input")
            return None
        agent = ClipMaker()
        return agent.create_video(input_data)

    elif agent_name == "thumb_wizard":
        if not input_data:
            print("Error: thumb_wizard requires a topic input")
            return None
        agent = ThumbWizard()
        return agent.create_thumbnail(input_data)

    elif agent_name == "upload_pilot":
        if not input_data:
            print("Error: upload_pilot requires a topic input")
            return None
        agent = UploadPilot()
        return agent.generate_metadata(input_data)

    else:
        print(f"Error: Unknown agent '{agent_name}'")
        return None

def run_pipeline(trend_index=0, output_dir=None):
    """
    Run the complete content creation pipeline.

    Args:
        trend_index (int): Index of the trending topic to use (0-based)
        output_dir (str, optional): Directory to save output files

    Returns:
        dict: Results of the pipeline run
    """
    start_time = time.time()

    # Create output directory if specified
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    print("\n" + "=" * 80)
    print(f"STARTING WARREN BLACK FINANCE SHORTS PIPELINE")
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    # Step 1: Find trending topics
    print("\n📊 STEP 1/6: Finding trending finance topics...")
    trend_seeker = TrendSeeker()
    topics = trend_seeker.get_trending_topics()

    # Select a topic based on the provided index
    if not topics:
        print("❌ Error: No trending topics found.")
        return None

    if trend_index >= len(topics):
        print(f"❌ Warning: Requested topic index {trend_index} is out of range. Using index 0 instead.")
        trend_index = 0

    selected_topic = topics[trend_index]
    print(f"\n✅ Selected topic: {selected_topic['title']}")

    # Step 2: Generate a script
    print("\n✍️ STEP 2/6: Generating Warren Black script...")
    script_smith = ScriptSmith()
    script = script_smith.generate_script(selected_topic)

    # Step 3: Convert script to voice
    print("\n🎙️ STEP 3/6: Creating voiceover...")
    vox_crafter = VoxCrafter()
    voice_result = vox_crafter.generate_voiceover(script)

    # Step 4: Create video with captions
    print("\n🎬 STEP 4/6: Creating video with captions...")
    clip_maker = ClipMaker()
    video_result = clip_maker.create_video(script)

    # Step 5: Generate thumbnail
    print("\n🖼️ STEP 5/6: Generating thumbnail...")
    thumb_wizard = ThumbWizard()
    thumbnail_result = thumb_wizard.create_thumbnail(selected_topic)

    # Step 6: Prepare upload metadata
    print("\n🚀 STEP 6/6: Preparing upload metadata...")
    upload_pilot = UploadPilot()
    metadata = upload_pilot.generate_metadata(selected_topic, script)

    # Compile results
    elapsed_time = time.time() - start_time
    results = {
        "pipeline_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_time": f"{elapsed_time:.2f} seconds",
        "topic": selected_topic,
        "script": script,
        "voice_result": voice_result,
        "video_result": video_result,
        "thumbnail_result": thumbnail_result,
        "metadata": metadata
    }

    # Save results to a summary file if output directory is specified
    if output_dir:
        summary_file = os.path.join(output_dir, "pipeline_summary.json")
        try:
            with open(summary_file, "w") as f:
                # Create a simplified version for JSON serialization
                simplified_results = {k: str(v) if isinstance(v, (dict, list)) and k != "metadata" else v 
                                     for k, v in results.items()}
                json.dump(simplified_results, f, indent=4)
            print(f"\n✅ Pipeline summary saved to: {summary_file}")
        except Exception as e:
            print(f"\n❌ Error saving pipeline summary: {e}")

    print("\n" + "=" * 80)
    print(f"✅ PIPELINE COMPLETED SUCCESSFULLY in {elapsed_time:.2f} seconds")
    print(f"Topic: {selected_topic['title']}")
    print("=" * 80)

    return results

def main():
    """Main function to run when script is executed directly."""
    parser = argparse.ArgumentParser(description="Warren Black Finance Shorts Automation Pipeline")

    parser.add_argument("--agent", "-a", type=str, choices=[
        "trend_seeker", "script_smith", "vox_crafter", 
        "clip_maker", "thumb_wizard", "upload_pilot"
    ], help="Run a specific agent instead of the full pipeline")

    parser.add_argument("--input", "-i", type=str, 
                       help="Input data for the agent (required for some agents)")

    parser.add_argument("--topic-index", "-t", type=int, default=0,
                       help="Index of the trending topic to use (default: 0)")

    parser.add_argument("--output-dir", "-o", type=str, default="output",
                       help="Directory to save output files (default: 'output')")

    args = parser.parse_args()

    # Create the output directory if it doesn't exist
    os.makedirs(args.output_dir, exist_ok=True)

    if args.agent:
        # Run a specific agent
        print(f"Running agent: {args.agent}")
        run_agent(args.agent, args.input)
    else:
        # Run the full pipeline
        run_pipeline(args.topic_index, args.output_dir)

if __name__ == "__main__":
    main()
